<?php                            //connection & credentials
$servername = "localhost";      //mysql is on the same host as apache
$dbname = "employees";          //which db you're going to use
$username = "lt";
$password = "123";
?>
